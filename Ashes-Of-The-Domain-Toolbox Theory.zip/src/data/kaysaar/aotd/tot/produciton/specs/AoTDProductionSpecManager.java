package data.kaysaar.aotd.tot.produciton.specs;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import data.kaysaar.aotd.tot.produciton.AoTDProducitonSpecListener;
import data.kaysaar.aotd.tot.produciton.models.AoTDProductionManData;
import data.kaysaar.aotd.vok.Ids.AoTDCommodities;
import data.kaysaar.aotd.vok.Ids.AoTDItems;
import data.kaysaar.aotd.vok.scripts.specialprojects.BlackSiteProjectManager;
import data.kaysaar.aotd.vok.scripts.specialprojects.models.ProjectReward;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;

public class AoTDProductionSpecManager {
    public static LinkedHashSet<WeaponAPI.WeaponType> blackListedTypes = new LinkedHashSet<>();
    public static boolean loaded = false;

    public static LinkedHashMap<String, AoTDProducitonSpecListener> listeners = new LinkedHashMap<>();

    public static void makeSureBlackListInitialized() {
        blackListedTypes.add(WeaponAPI.WeaponType.LAUNCH_BAY);
        blackListedTypes.add(WeaponAPI.WeaponType.BUILT_IN);
        blackListedTypes.add(WeaponAPI.WeaponType.DECORATIVE);
        blackListedTypes.add(WeaponAPI.WeaponType.SYSTEM);
        blackListedTypes.add(WeaponAPI.WeaponType.STATION_MODULE);
    }

    public static void addListener(String id, AoTDProducitonSpecListener listener) {
        listeners.put(id, listener);
    }

    public static LinkedHashMap<String, AoTDProductionSpec> shipProdSpecs = new LinkedHashMap<>();
    public static LinkedHashMap<String, AoTDProductionSpec> weaponProdSpecs = new LinkedHashMap<>();

    public static LinkedHashMap<String, AoTDProductionSpec> fighterProdSpecs = new LinkedHashMap<>();

    public static LinkedHashMap<String, AoTDProductionSpec> specialItemProdSpecs = new LinkedHashMap<>();
    public static ArrayList<AoTDProductionManData> manData = new ArrayList<>();
    public static LinkedHashSet<String> orderedItemsForUI = new LinkedHashSet<>();

    static {
        orderedItemsForUI.add(Commodities.SHIPS);
        orderedItemsForUI.add(Commodities.HAND_WEAPONS);
        if (Global.getSettings().getModManager().isModEnabled("aotd_vok")) {
            orderedItemsForUI.add(AoTDCommodities.ADVANCED_COMPONENTS);
            orderedItemsForUI.add(AoTDCommodities.REFINED_METAL);
            orderedItemsForUI.add(AoTDCommodities.PURIFIED_TRANSPLUTONICS);
            orderedItemsForUI.add(AoTDCommodities.DOMAIN_GRADE_MACHINERY);
            orderedItemsForUI.add(AoTDItems.TENEBRIUM_CELL);
        }


    }

    public static LinkedHashMap<String, AoTDProductionSpec> getSpecsBasedOnType(AoTDProductionSpec.AoTDProductionSpecType type) {
        return switch (type) {
            case SHIP -> shipProdSpecs;
            case WEAPON -> weaponProdSpecs;
            case FIGHTER -> fighterProdSpecs;
            case COMMODITY_ITEM -> specialItemProdSpecs;
            case SPECIAL_ITEM -> specialItemProdSpecs;
        };
    }

    public static void generateSpecsForAllStuff() {
        if (loaded) return;

        makeSureBlackListInitialized();
        shipProdSpecs.clear();
        weaponProdSpecs.clear();
        fighterProdSpecs.clear();
        specialItemProdSpecs.clear();
        manData.clear();
        if (Global.getSettings().getModManager().isModEnabled("aotd_vok")) {
            manData.addAll(AoTDProductionManData.getManufacturerDataFromCSV());
        }
        for (ShipHullSpecAPI allShipHullSpec : Global.getSettings().getAllShipHullSpecs()) {
            if (allShipHullSpec.getHints().contains(ShipHullSpecAPI.ShipTypeHints.STATION)) continue;
            if (allShipHullSpec.getHints().contains(ShipHullSpecAPI.ShipTypeHints.MODULE)) continue;
//            if (allShipHullSpec.getHints().contains(ShipHullSpecAPI.ShipTypeHints.UNBOARDABLE)) continue; // Made automated ships disappear from production
            if (allShipHullSpec.getHints().contains(ShipHullSpecAPI.ShipTypeHints.UNDER_PARENT)) continue;
            if (allShipHullSpec.getHullSize().equals(ShipAPI.HullSize.FIGHTER)) continue;
            if (allShipHullSpec.hasTag(Tags.MODULE_HULL_BAR_ONLY)) continue;
            if (Global.getSettings().getHullIdToVariantListMap().get(allShipHullSpec.getHullId()).isEmpty()) {
                boolean found = false;
                for (String allVariantId : Global.getSettings().getAllVariantIds()) {
                    if (allVariantId.contains(allShipHullSpec.getHullId())) {
                        found = true;
                        break;
                    }

                }
                if (!found) continue;
            }

            shipProdSpecs.put(allShipHullSpec.getHullId(), new AoTDProductionSpec(allShipHullSpec.getHullId(), allShipHullSpec));

        }
        for (WeaponSpecAPI weaponSpecAPI : Global.getSettings().getAllWeaponSpecs()) {
            if (blackListedTypes.contains(weaponSpecAPI.getType())) continue;

            weaponProdSpecs.put(weaponSpecAPI.getWeaponId(), new AoTDProductionSpec(weaponSpecAPI.getWeaponId(), weaponSpecAPI));
        }
        for (FighterWingSpecAPI allFighterWingSpec : Global.getSettings().getAllFighterWingSpecs()) {

            fighterProdSpecs.put(allFighterWingSpec.getId(), new AoTDProductionSpec(allFighterWingSpec.getId(), allFighterWingSpec));
        }
        ArrayList<String> allowedItems = new ArrayList<>();
        try {
            JSONArray array = Global.getSettings().getJSONArray("aotd_item_prod");
            for (int i = 0; i < array.length(); i++) {
                String obj = array.getString(i);
                allowedItems.add(obj);

            }
        } catch (JSONException e) {

        }
        for (SpecialItemSpecAPI allSpecialItemSpec : Global.getSettings().getAllSpecialItemSpecs()) {
            if (!allowedItems.contains(allSpecialItemSpec.getId())) continue;

            specialItemProdSpecs.put(allSpecialItemSpec.getId(), new AoTDProductionSpec(allSpecialItemSpec.getId(), allSpecialItemSpec));
        }
        for (CommoditySpecAPI s : Global.getSettings().getAllCommoditySpecs()) {
            if (!allowedItems.contains(s.getId())) continue;

            specialItemProdSpecs.put(s.getId(), new AoTDProductionSpec(s.getId(), s));

        }
        listeners.values().forEach(AoTDProducitonSpecListener::specsCreated);
        loaded = true;
    }

    public static AoTDProductionManData getManDataIfPresent(String manufacturer) {
        for (AoTDProductionManData manDatum : manData) {
            if (manDatum.getManufacturerId().equalsIgnoreCase(manufacturer)) {
                return manDatum;
            }
        }
        return null;
    }

    public static AoTDProductionSpec getShipSpec(String id) {
        return shipProdSpecs.get(id);
    }

    public static AoTDProductionSpec getWeaponSpec(String id) {
        return weaponProdSpecs.get(id);
    }

    public static AoTDProductionSpec getFighterSpec(String id) {
        return fighterProdSpecs.get(id);
    }

    public static AoTDProductionSpec getSpec(String id, AoTDProductionSpec.AoTDProductionSpecType type) {
        if (id == null || type == null) return null;

        return switch (type) {
            case SHIP -> shipProdSpecs.get(id);
            case WEAPON -> weaponProdSpecs.get(id);
            case FIGHTER -> fighterProdSpecs.get(id);
            case SPECIAL_ITEM, COMMODITY_ITEM -> specialItemProdSpecs.get(id);
        };
    }

    public static AoTDProductionSpec getSpecialItemSpec(String id) {
        return specialItemProdSpecs.get(id);
    }

    public static AoTDProductionSpec getNormalItemSpec(String id) {
        return specialItemProdSpecs.get(id);
    }

    public static List<AoTDProductionSpec> getLearnedSpecsForFaction(AoTDProductionSpec.AoTDProductionSpecType type, FactionAPI faction) {
        return getSpecsBasedOnType(type).values().stream().filter(x -> x.isLearnedByFaction(faction)).toList();
    }

}
