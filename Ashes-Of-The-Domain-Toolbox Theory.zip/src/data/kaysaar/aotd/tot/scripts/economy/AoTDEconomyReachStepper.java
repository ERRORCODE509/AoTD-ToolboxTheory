package data.kaysaar.aotd.tot.scripts.economy;

import com.fs.starfarer.api.Global;
import ashlib.data.plugins.events.AshlibBaseEventManager;
import data.kaysaar.aotd.tot.events.AoTDColonyDemandShockEvent;
import data.kaysaar.aotd.tot.events.TradeVolatilitySettings;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MonthlyReport;
import com.fs.starfarer.api.campaign.econ.MonthlyReport.FDNode;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.campaign.econ.Economy;
import com.fs.starfarer.campaign.econ.contract.ContractEconomy;
import com.fs.starfarer.campaign.econ.contract.iter.MultiFrameTask;
import com.fs.starfarer.campaign.econ.reach.*;
import data.kaysaar.aotd.tot.events.AoTDTradeDemandEvent;
import data.kaysaar.aotd.tot.scripts.commoditydata.AoTDCommodityOnMarket;
import data.kaysaar.aotd.tot.scripts.trade.*;
import data.kaysaar.aotd.tot.scripts.trade.contracts.AoTDTradeContractManager;
import data.kaysaar.aotd.tot.scripts.trade.manager.AoTDTradeManager;
import data.kaysaar.aotd.tot.scripts.trade.models.AoTDFactionTradeData;
import data.kaysaar.aotd.tot.scripts.trade.models.AoTDMarketData;
import data.kaysaar.aotd.tot.scripts.trade.tasks.AoTDExternalTradeSolver;
import data.kaysaar.aotd.tot.scripts.trade.tasks.AoTDFactionInternalTradeTask;
import data.kaysaar.aotd.tot.ui.income.AoTDMonthlyTooltipCreator;

import java.util.ArrayList;
import java.util.Map;

public class AoTDEconomyReachStepper extends ReachEconomyStepper {
    private ReachEconomy econ;
    private State state;
    private float elapsed;
    private float untilNext;
    private int iterLeft;
    private int prevMonth;

    private transient AoTDEconomyPerformanceProfiler.StepProfile stepProfile;
    private transient AoTDEconomyPerformanceProfiler.RollingProfile rollingProfile;
    private transient int profileTaskIndex;

    public AoTDEconomyReachStepper(ReachEconomy reachEconomy) {
        super(reachEconomy);
        state = ReachEconomyStepper.State.WAITING;
        elapsed = 1000f;
        untilNext = 3f;
        iterLeft = Economy.NUM_ITER_PER_MONTH;
        prevMonth = -1;
        econ = reachEconomy;
    }

    public void doEconomyTick() {
        if (!AoTDReachEconomy.PROFILE_NEXT_STEP) {
            doEndOfStepStuff(-1);
            return;
        }
        long started = System.nanoTime();
        doEndOfStepStuff(-1);
        Global.getLogger(AoTDEconomyReachStepper.class).info(String.format(java.util.Locale.ROOT,
                "AoTD reachStep manualEndStep=%.3fms", (System.nanoTime() - started) / 1_000_000d));
    }

    @Override
    protected void doEndOfMonthStuff() {
        final MonthlyReport report = SharedData.getData().getCurrentReport();

        if(report != null){
            final FDNode marketsNode = report.getNode(MonthlyReport.OUTPOSTS);

            for (MarketAPI market : Misc.getPlayerMarkets(true)) {
                final FDNode mNode = report.getNode(marketsNode, market.getId());
                final FDNode indNode = report.getNode(mNode, "industries");

                for (Industry industry : market.getIndustries()) {
                    final FDNode iNode = report.getNode(indNode, industry.getId());
                    iNode.tooltipCreator = new AoTDMonthlyTooltipCreator();
                }

                final FDNode exportNode = report.getNode(mNode, "exports");
                for (CommodityOnMarketAPI com : market.getCommoditiesCopy()) {
                    final FDNode eNode = report.getNode(exportNode, com.getId());
                    eNode.income = AoTDTradeManager.getExportIncome(com);
                    eNode.tooltipCreator = new AoTDMonthlyTooltipCreator();
                }
            }
        }

        AoTDTradeManager.endOfMonth = false;
        super.doEndOfMonthStuff();
    }

    @Override
    public ReachEconomy getEconomy() {
        return econ;
    }

    @Override
    public void setEcon(ReachEconomy reach) {
        econ = reach;
    }

    public void performBeforeMonthEnds(int prevMonth) {
        boolean profile = AoTDReachEconomy.PROFILE_NEXT_STEP;
        long started = profile ? System.nanoTime() : 0L;
        long last = started;
        long[] phases = profile ? new long[7] : null;
        int marketCount = 0;
        int eligible = 0;
        SectorSurplusConsumptionStats.getInstance().clear();

        for (AoTDFactionTradeData tradeData : AoTDTradeManager.getInstance().getAllFactionTradeData().values()) {
            tradeData.doEndOfMonthStuffForHistory(prevMonth);
        }
        if (profile) {
            long now = System.nanoTime();
            phases[0] = now - last;
            last = now;
        }

        if (!AoTDEconomy.runningPrePlayerEconomy) {
            // Rebuild balances before contracts and external allocation when trade orders changed.
            if (AoTDTradeDemandEvent.prepareForMonthlyAllocation()) {
                AoTDTradeManager manager = AoTDTradeManager.getInstance();
                for (AoTDFactionTradeData tradeData : manager.getAllFactionTradeData().values()) {
                    tradeData.reset();
                }
                for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
                    manager.addMarket(market);
                }
                Map<String, MarketAPI> marketsById = AoTDFactionTradeData.snapshotMarketsById();
                for (AoTDFactionTradeData tradeData : manager.getAllFactionTradeData().values()) {
                    tradeData.computeInternalTrade(false, marketsById);
                }
                AoTDTradeContractManager.getInstance().invalidatePredictions();
            }
            if (profile) {
                long now = System.nanoTime();
                phases[1] = now - last;
                last = now;
            }

            Map<String, MarketAPI> monthlyMarkets = AoTDFactionTradeData.snapshotMarketsById();
            AoTDIsolationUtils.prepareMarkets(monthlyMarkets.values());
            for (AoTDFactionTradeData tradeData : AoTDTradeManager.getInstance().getAllFactionTradeData().values()) {
                tradeData.computeInternalTrade(false, monthlyMarkets);
            }
            AoTDIsolationUtils.computeLocalTrade(monthlyMarkets);
            AoTDTradeContractManager.getInstance().invalidatePredictions();
            AoTDTradeContractManager.getInstance().runMonthlyContracts();
            if (profile) {
                long now = System.nanoTime();
                phases[2] = now - last;
                last = now;
            }

            // Build external index from remainingNet (post-internal, post-contract).
            final AoTDSectorExternalIndex idx = new AoTDSectorExternalIndex();
            for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
                if (profile) marketCount++;
                final AoTDFactionTradeData f = AoTDTradeManager.getInstance().getFactionTradeData(market.getFactionId());
                final AoTDMarketData md = f.getTradeData().get(market.getId());
                if (md == null) continue;

                md.resetExternalResults();
                if(!market.hasSpaceport()||market.getAccessibilityMod().computeEffective(0f)<=0f)continue;
                idx.addMarket(market, md);
                if (profile) eligible++;
            }
            if (profile) {
                long now = System.nanoTime();
                phases[3] = now - last;
                last = now;
            }

            new AoTDExternalTradeSolver().runMonthEndExternalTrade(idx);
            if (profile) {
                long now = System.nanoTime();
                phases[4] = now - last;
                last = now;
            }

            final float durDays = 31;
            for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
                AoTDFactionTradeData f = AoTDTradeManager.getInstance().getFactionTradeData(market.getFactionId());
                AoTDMarketData md = f.getTradeData().get(market.getId());
                if (md == null) continue;
                AoTDIndustryData.getInstance(market).applyEndOfMonthChange(market);
                for (CommodityOnMarketAPI c : market.getAllCommodities()) {
                    if (!(c instanceof AoTDCommodityOnMarket com)) continue;
                    com.getExcDefData().clearExternalTrade(com);
                    String commodityId = com.getId();
                    int r = md.getRemainingNet(commodityId);

                    int deficit = Math.max(0, -r);
                    int excess = Math.max(0, r);

                    com.getExcDefData().recordDemandForThisMonth(com);
                    com.getExcDefData().applyExternalTrade(deficit, excess, durDays, com);
                }
            }
            if (profile) {
                long now = System.nanoTime();
                phases[5] = now - last;
                last = now;
            }

            AshlibBaseEventManager events = AshlibBaseEventManager.getInstance();
            for (int day = 1; day <= 2; day++) {
                events.scheduleMinorEventTrigger(AoTDColonyDemandShockEvent.TRIGGER_ID, day,
                        TradeVolatilitySettings.colonyShockAttemptsPerDay, TradeVolatilitySettings.colonyShockChance);
            }
        } else {
            for (MarketAPI marketAPI : Global.getSector().getEconomy().getMarketsCopy()) {
                AoTDIndustryData.getInstance(marketAPI).applyEndOfMonthChange(marketAPI);
                if (profile) marketCount++;
            }
            if (profile) {
                long now = System.nanoTime();
                phases[5] = now - last;
                last = now;
            }
        }
        if (profile) {
            phases[6] = System.nanoTime() - last;
            AoTDEconomyPerformanceProfiler.logMonthEnd(prevMonth, marketCount, eligible, phases,
                    System.nanoTime() - started);
        }
    }

    @Override
    public void nextFrame(float delta) {
        elapsed += delta;
        ContractEconomy.DEBUG = false;

        if (state == ReachEconomyStepper.State.WAITING) {
            final int month = Global.getSector().getClock().getMonth();
            if (month != prevMonth) {
                final int prevMonth = this.prevMonth;
                this.prevMonth = month;
                iterLeft = Economy.NUM_ITER_PER_MONTH;

                final float daysInThisMonth = getNumDaysInCurrMonth() - Global.getSector().getClock().getDay();
                untilNext = daysInThisMonth / ((float) Economy.NUM_ITER_PER_MONTH + 0f);
                elapsed = untilNext / 2f;
                performBeforeMonthEnds(prevMonth);
                AoTDTradeManager.endOfMonth = true;
                long endStarted = AoTDReachEconomy.PROFILE_NEXT_STEP ? System.nanoTime() : 0L;
                doEndOfStepStuff(Economy.NUM_ITER_PER_MONTH - 1);
                if (AoTDReachEconomy.PROFILE_NEXT_STEP) {
                    Global.getLogger(AoTDEconomyReachStepper.class).info(String.format(java.util.Locale.ROOT,
                            "AoTD monthEnd endStep=%.3fms", (System.nanoTime() - endStarted) / 1_000_000d));
                }
                long monthStarted = AoTDReachEconomy.PROFILE_NEXT_STEP ? System.nanoTime() : 0L;
                doEndOfMonthStuff();
                if (AoTDReachEconomy.PROFILE_NEXT_STEP) {
                    Global.getLogger(AoTDEconomyReachStepper.class).info(String.format(java.util.Locale.ROOT,
                            "AoTD monthEnd reportAndFinish=%.3fms", (System.nanoTime() - monthStarted) / 1_000_000d));
                }
            }
        }

        if (state == ReachEconomyStepper.State.WAITING && !AoTDEconomy.runningPrePlayerEconomy) {
            AshlibBaseEventManager.getInstance().advanceMinorEventTriggers();
        }

        if (state == ReachEconomyStepper.State.WAITING && elapsed >= untilNext && iterLeft > 0) {
            --iterLeft;
            state = ReachEconomyStepper.State.DOING_TASKS;
            tasks = null;
            elapsed = 0f;
        }

        if (state == ReachEconomyStepper.State.DOING_TASKS) {
            if (tasks == null) createTasks();
            if (isDone()) return;

            final MultiFrameTask firstTask = (MultiFrameTask) tasks.get(0);
            if (stepProfile != null) stepProfile.nextFrame();
            long started = stepProfile != null ? System.nanoTime() : 0L;
            firstTask.advance(delta);
            if (stepProfile != null) stepProfile.add(profileTaskIndex, System.nanoTime() - started);
            if (firstTask.isDone()) {
                tasks.remove(0);
                profileTaskIndex++;
            }

            if (isDone()) {
                long postStarted = stepProfile != null ? System.nanoTime() : 0L;
                if (iterLeft > 0) {
                    doEndOfStepStuff(Economy.NUM_ITER_PER_MONTH - iterLeft - 1);
                }
                if (stepProfile != null) {
                    stepProfile.add(5, System.nanoTime() - postStarted);
                    stepProfile.log();
                    if (rollingProfile == null) rollingProfile = new AoTDEconomyPerformanceProfiler.RollingProfile();
                    rollingProfile.add(stepProfile);
                    stepProfile = null;
                }
                state = ReachEconomyStepper.State.WAITING;
            }
        }
    }

    private void createTasks() {
        AoTDIsolationUtils.prepareMarkets(AoTDEconomy.getInstance().getMarkets());
        tasks = new ArrayList<>();
        final boolean iterationsDone = iterLeft <= 0;
        final MainWorkTask.EconWorkParams mainWork = new MainWorkTask.EconWorkParams();
        mainWork.withIncomeAndUpkeep = true;
        mainWork.withStockpileUpdate = iterationsDone;

        final Economy mainEcon = (Economy) Global.getSector().getEconomy();
        tasks.add(new AoTdMainWorkTask2(econ.getMarkets(), econ, mainWork));
        tasks.add(new AoTDUpdateMarketAgainTask(mainEcon));
        tasks.add(new ImmigrationTask(econ.getMarkets(), econ, false));
        tasks.add(new AoTDFactionInternalTradeTask(mainEcon));
        tasks.add(new AoTDFinishEconomyUpdateTask(mainEcon));

        profileTaskIndex = 0;
        stepProfile = AoTDReachEconomy.PROFILE_NEXT_STEP
                ? new AoTDEconomyPerformanceProfiler.StepProfile(
                        "campaign", Economy.NUM_ITER_PER_MONTH - iterLeft, econ.getMarkets(), mainWork)
                : null;
    }

    public final float getNumDaysInCurrMonth() {
        return Global.getSector().getClock().getCal().getActualMaximum(5);
    }
}
